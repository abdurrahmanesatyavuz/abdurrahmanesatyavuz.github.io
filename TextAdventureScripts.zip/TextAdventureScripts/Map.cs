﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;

namespace J1P2_PRO_Prototype2_Esat_Yavuz
{
    internal class Map
    {
        /// <summary>
        /// An array of locations which makes the map of the game.
        /// </summary>
                                       //locationAccess   locationName           enemyChance    locationloot                            locationAscii
        public Location[] mapArray =
        {
            new Location( new List <int> {1, 2},          "Gas Station (1)",           0,       new List<string>{""},                    File.ReadAllText(@"TextAdventure_GasStation.txt")),
            new Location( new List <int> {2, 1, 3, 4},    "Warehouse (2)",             1,       new List<string>{""},                    File.ReadAllText(@"TextAdventure_Warehouse.txt")),
            new Location( new List <int> {3, 2, 4, 7},    "Blue House (3)",            1,       new List<string>{"Plum"},                File.ReadAllText(@"TextAdventure_BlueHouse.txt")),
            new Location( new List <int> {4, 2, 3, 5},    "Red House (4)",             1,       new List<string>{"Apple"},               File.ReadAllText(@"TextAdventure_RedHouse.txt")),
            new Location( new List <int> {5, 4, 8, 9},    "Hospital (5)",              1,       new List<string>{"Bandage"},             File.ReadAllText(@"TextAdventure_Hospital.txt")),
            new Location( new List <int> {6, 7},          "Mosque (6)",                0,       new List<string>{"Cemetery Key"},        File.ReadAllText(@"TextAdventure_Mosque.txt")),
            new Location( new List <int> {7, 3, 6, 8},    "School (7)",                1,       new List<string>{"Pear"},                File.ReadAllText(@"TextAdventure_School.txt")),
            new Location( new List <int> {8, 7, 9},       "Police Station (8)",        1,       new List<string>{""},                    File.ReadAllText(@"TextAdventure_PoliceStation.txt")),
            new Location( new List <int> {9, 5, 8},       "Military Checkpoint (9)",   0,       new List<string>{""},                    File.ReadAllText(@"TextAdventure_MilitaryCheckpoint.txt")),
            new Location( new List <int> {10, 9},         "Cemetery (10)",             0,       new List<string>{""},                    @"")
        };
    }
}