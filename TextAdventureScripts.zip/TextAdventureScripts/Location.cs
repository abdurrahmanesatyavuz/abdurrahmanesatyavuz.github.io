﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace J1P2_PRO_Prototype2_Esat_Yavuz
{
    internal class Location
    {
        // All of the things I want a locations to have as variables

        List<int> locationAccess;
        string locationName;
        int enemyChance;
        List<string> locationLoot;
        string locationAscii;

        /// <summary>
        /// Here I declare everything a location should have and set them to their actual variables
        /// </summary>

        public Location(List<int> pLocationAccess, string pLocationName, int pEnemyChance, List<string>pLocationLoot, string pLocationAscii) 
        {
            locationAccess = pLocationAccess;
            locationName = pLocationName;
            enemyChance = pEnemyChance;
            locationLoot = pLocationLoot;
            locationAscii = pLocationAscii;
        }

        // Here I return all of the variables I have so I can make checks with stuff like if statements for how my game and map work 

        public List<int> GetLocationAccess() // A variable function, has to always return something like right now it returns the private variable locationAcces.
        {
            return locationAccess;
        }

        public string GetLocationName()
        {
            return locationName;
        }

        public int GetEnemyChance()
        {
            return enemyChance;
        }

        public List<string> GetLocationLoot()
        {
            return locationLoot;
        }

        public string GetLocationAscii() 
        {
            return locationAscii;
        }
    }
}