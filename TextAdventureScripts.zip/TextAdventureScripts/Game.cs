﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace J1P2_PRO_Prototype2_Esat_Yavuz
{
    internal class Game
    {
        // I declared the three classes I need here and set their values in the constructor

        Tools tls;
        Combat cmbt;
        Map map;

        string playerName; // A string saves a bunch of charachters and a char saves only one charachter
        string menuChoice;

        // an array is a group of multiple values of the same variable type in one variable with an index that starts at zero [0]

        string[] rndFruit = { "Apple", "Pear", "Plum" }; // A string array of random fruits

        string introAscii = File.ReadAllText(@"L1P2_PRO_TextAdventure_Ascii_Logo.txt"); // Here I use the ReadAllText function to get the whole txt file into a string variable
        string soldierAscii = File.ReadAllText(@"TextAdventure_Soldier.txt");

        // the int saves numbers so you can do calculations in the code.

        int playerLocation = 0; // Int for the location of the player

        bool prologueStarted = false; // a boolean is either true or false
        bool movementCheck = false;
        bool enemyAtLocation = false;
        bool checkpointCutscene = false;

        public Game()
        {
            tls = new Tools(); 
            cmbt = new Combat(tls);
            tls.SetCombat(cmbt); // Declared cmbt for tools class so i dont have to put cmbt or this in parameters to get it working
            map = new Map();
            GameLoop();
            GameIntro();
        }

        void GameIntro()
        {
            tls.Print("To get the full experience, make the console fullscreen. ", 20); // tls. is used because the function is in another class, this is the same for map or cmbt.

            tls.PressAnyKeyToContinue();

            tls.Print(introAscii, 0);

            tls.Print("\nHello!, Welcome to Tale of Svetlojarsk.\nWhat is your name?", 20);
            playerName = Console.ReadLine(); // asks input of the user

            Console.Clear(); 

            tls.Print($"So {playerName}, what would you like to do?", 20);

            while (prologueStarted == false) // A while loop will loop anything in its scope until the given condition is false
            {
                menuChoice = tls.UserInput();
                Console.Clear();

                if (menuChoice == "play" || menuChoice == "start") // An if statement will execute everything in its scope when the (two in this case since its a || which makes it so you can have multiple conditions in one if statement) conditions is true
                {
                    GamePrologue();
                }

                else
                {
                    tls.Print("If you would like to start a new game please input play or start.", 20);
                }
            }
        }

        void GamePrologue()
        {
            prologueStarted = true;

            cmbt.GetPlayerInventory().Add(rndFruit[tls.RandomNumGen(0, rndFruit.Length)]);

            tls.Print($"You wake up on a coast with a t-shirt, cargo pants and sneakers on.\nYou have on you: ", 20);

            tls.Print(tls.InventorySorter(), 20);

            tls.Print("\n", 20);

            tls.PressAnyKeyToContinue();

            tls.Print("You dont understand what has happend or where you are, the only thought you have in your mind is: It's pretty cold today.\nYou start looking around you and see a road along the coast.", 20);

            string walkOrWait = tls.UserInput();

            if (walkOrWait == "walk" || walkOrWait == "start walking")
            {
                Console.Clear();
                tls.Print("You start walking down the road...\n\n\nAfter a while you see a gas station and a sign saying 'Welcome to Svetlojarsk!'.", 20);
                tls.PressAnyKeyToContinue();
                GameLoop();
            }

            else
            {
                Console.Clear();
                tls.Print("After a while you start walking down the road...\n\n\nAnd you see a gas station and a sign saying 'Welcome to Svetlojarsk!'.", 20);
                tls.PressAnyKeyToContinue();
                GameLoop();
            }
        }

        void GameLoop()
        {
            tls.Print("(Now you will enter the actual playable game. Input the number with the corresponding location to go there. To pick something up just write pick up. If you need help with what you can do just type help.)", 20);

            tls.PressAnyKeyToContinue();

            do // Do while loop does the loop once before checking the condition and continues to loop until not true
            {
                cmbt.GetPlayerInventory().Add("Cemetery Key"); // functuin add adds the given argument to the inventory

                if (playerLocation == 8 && checkpointCutscene == false) // The && makes it so both of the conditions have to be true to execute the if statement
                {
                    MilitaryCutscene();
                }

                if (cmbt.GetPlayerInventory().Contains("Cemetery Key") && playerLocation == 8)
                {
                    map.mapArray[8].GetLocationAccess().Add(10);

                    tls.Print("\n\nSoldier: Hey you have the cemetery key! Be careful though, there is a dangerous viscacha there.\n", 20);

                    tls.PressAnyKeyToContinue();
                }

                tls.Print($"{map.mapArray[playerLocation].GetLocationAscii()}\n\n", 0);

                tls.Print($"You are currently in:\n{map.mapArray[playerLocation].GetLocationName()}", 20);

                List<int> accesibleLocations = map.mapArray[playerLocation].GetLocationAccess(); // A list of all the accissible streets, first it goes into the mapArray with the player location as index and then it returns it

                tls.Print("\n\nYou can go to:", 20);

                for (int i = 1; i < accesibleLocations.Count; i++)
                {
                    tls.Print($"\n{map.mapArray[accesibleLocations[i] - 1].GetLocationName()}", 20);
                }

                tls.Print("\n\nYou can pick up:", 20);

                for (int i = 0; i < map.mapArray[playerLocation].GetLocationLoot().Count; i++)
                {
                    tls.Print($"\n{map.mapArray[playerLocation].GetLocationLoot()[i]}\n\n", 20);
                }

                string pInput = tls.UserInput();

                if (pInput == "pick up")
                {
                    if (map.mapArray[playerLocation].GetLocationLoot()[0] != "")
                    {
                        tls.Print($"\nYou have picked up: {map.mapArray[playerLocation].GetLocationLoot()[0]}.\n", 20);

                        cmbt.GetPlayerInventory().Add(map.mapArray[playerLocation].GetLocationLoot()[0]);

                        map.mapArray[playerLocation].GetLocationLoot().Remove(map.mapArray[playerLocation].GetLocationLoot()[0]);
                    }

                    else
                    {
                        tls.Print("There is nothing to pick up!", 20);
                    }

                    tls.PressAnyKeyToContinue();

                    tls.InputCheckTrue();
                }

                try // try catch tries the code in the try statement and if it has an error then it goes to the catch statement and runs that instead.
                {
                    for (int i = 1; i < accesibleLocations.Count; i++)
                    {
                        if (map.mapArray[accesibleLocations[i] - 1].GetLocationAccess()[0] == int.Parse(pInput))
                        {
                            playerLocation = int.Parse(pInput) - 1;
                            movementCheck = true;

                            if (map.mapArray[accesibleLocations[i] - 1].GetEnemyChance() > tls.RandomNumGen(0, 2))
                            {
                                tls.Print("There is a zombie at your location!\n", 20);
                                enemyAtLocation = true;
                            }
                        }
                    }
                    //This for loop checks if you can actually go there if you cannot then it redirects you with a boolean
                }
                catch
                {
                    movementCheck = false;
                }

                if (movementCheck == false && tls.GetInputCheck() == false)
                {
                    tls.Print("You can not move there!\n(Please only input the number that corresponds with the location.)\n\n", 20);
                }

                if (enemyAtLocation != false)
                {
                    cmbt.CombatCheck();
                }

                if (cmbt.GetPlayerBleeding() == true)
                {
                    cmbt.PlayerBleeding();
                    tls.PressAnyKeyToContinue();
                }

                if (cmbt.GetPlayerInventory().Contains("Cemetery Key") && playerLocation == 8)
                {
                    map.mapArray[8].GetLocationAccess().Add(10);

                    tls.Print("\n\nSoldier: Hey you have the cemetery key! Be careful though, there is a dangerous viscacha there.\n", 20);
                }

                movementCheck = false;
                enemyAtLocation = false;
                tls.InputCheckFalse();
            }
            while (cmbt.GetPlayerHP() >= 0); // Here is the condition for the do while loop
        }

        void MilitaryCutscene() // A normal void function, just runs all of the things inside of it.
        {
            Console.Clear();

            tls.Print(soldierAscii, 0);

            tls.Print("\nSoldier: Hey stop where you are!\n", 30);

            tls.Print($"\n{playerName}: Don't shoot I am a human!\n", 30);

            tls.Print("\nSoldier: Have you been bitten or scratched by any zombies?\n", 30);

            tls.Print($"\n{playerName}: Well, I have but im alright now\n", 30);

            tls.Print("\nSoldier: Well come on in, just don't do anything wierd or I might have to shoot you, hahahaha.\n", 30);

            tls.Print($"\n{playerName}: ...\n", 100);

            tls.PressAnyKeyToContinue();

            tls.Print(soldierAscii, 0);

            if (cmbt.GetPlayerInventory().Contains("Cemetery Key"))
            {
                map.mapArray[8].GetLocationAccess().Add(10);

                tls.Print("\n\nSoldier: Hey you have the cemetery key! Be careful though, there is a dangerous viscacha there.\n", 20);
            }

            // The ! you see under this comment is to make the else if execute if the given condition is not true. So bassicly its true if the condition is false

            else if (!cmbt.GetPlayerInventory().Contains("Cemetery Key")) // An else if statement is an alternative for the if statement, if the if statement returns false it goes and checks the else if statement to see if its conditions are true
            {
                tls.Print("\n\nSoldier: Hey if you want to go into the cemetery there is a key in the Mosque. Be careful though in the cemetery is a dangerous viscacha there.", 20);
            }

            tls.PressAnyKeyToContinue();

            checkpointCutscene = true;
        }
    }
}