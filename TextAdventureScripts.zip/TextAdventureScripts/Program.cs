﻿namespace J1P2_PRO_Prototype2_Esat_Yavuz
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {
            new Game();
        }
    }
}