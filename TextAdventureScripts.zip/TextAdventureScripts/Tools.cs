﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace J1P2_PRO_Prototype2_Esat_Yavuz
{
    internal class Tools
    {
        Combat cmbt;

        bool inputCheck = false;

        /// <summary>
        /// I have set cmbt here in this function so I dont have to do it elsewhere.
        /// </summary>

        public void SetCombat(Combat pCmbt) 
        {
            cmbt = pCmbt;
        }

        /// <summary>
        /// This is my own sort of console.write but with a foreach and thread.sleep so it makes text output slower, the foreach works by first converting everything in parameter text to a char array and then looping through it each time.
        /// </summary>

        public void Print(string text, int delay) // A public function makes it so I can call it in other classes
        {
            foreach (char c in text.ToCharArray())
            {
                Console.Write(c);
                Thread.Sleep(delay); // This function makes the application wait as much as the time int the parantheses is
            }
        }

        /// <summary>
        /// This checks the input and returns it if you havent typed anything like help, which if you have will print out text that is in the case it returns everything you write.
        /// </summary>

        public string UserInput()
        {
            inputCheck = true;

            string input = Console.ReadLine().ToLower();
            
            switch (input) // a switch case with input as a argument 
            {
                case "quit": // A case has to match with the argument that is given to run
                    Console.Clear();
                    Print("Press any key to quit, thanks for playing and goodbye!", 20);
                    Console.ReadKey(true);
                    Thread.Sleep(100);
                    Environment.Exit(0);
                    break;
                case "inv": // One case can have more then one argument
                case "inventory":
                    Print("Your inventory: ", 20);
                    Print(InventorySorter(), 20);
                    break;
                case "help":
                    Print("\nTo quit the game, type quit.\nTo see your inventory, type inventory.\nTo see the credits, type credits.\n To see your health, type hp.\nTo use a bandage, type bandage.\nTo heal, type heal.\nTo pick something up just write pick up\n", 20);
                    break;
                case "credits":
                    Credits();
                    break;
                case "hp":
                case "health":
                case "stats":
                case "statistics":
                    Print($"Your HP is: {cmbt.GetPlayerHP()}", 20);
                    break;
                case "bandage":
                case "use bandage":
                    cmbt.PlayerStoppedBleeding();
                    cmbt.GetPlayerInventory().Remove("Bandage");
                    Print("A bandage has been removed from your inventory.", 20);
                    break;
                case "heal":
                case "eat":
                case "eat plum":
                case "eat pear":
                case "eat apple":
                case "plum":
                case "pear":
                case "apple":
                    cmbt.PlayerHealing();
                    break;
                default: // The break will run if the argument given does not match with any case.
                    inputCheck = false;
                    break;
            }

            PressAnyKeyToContinue();

            return input; // returns input to the place you called it
        }

        /// <summary>
        /// This is a basic function which prints press any key to continue with a readkey that clears the console.
        /// </summary>

        public void PressAnyKeyToContinue()
        {
            Console.WriteLine("\n\nPress any key to continue."); // Makes a new line in the console and outputs what you have put in the parantheses like a variable or a text
            Console.ReadKey(true); // Ask a key input from the user if it wasnt (true) then the pressed key will be shown in the console
            Console.Clear(); // clears the console
        }

        /// <summary>
        /// Sorts the inventory so its easy to print.
        /// </summary>

        public string InventorySorter()
        {
            string a = "";

            for (int i = 0; i < cmbt.GetPlayerInventory().Count; i++) // For loop will loop so long the second statement is true and will add an increment to int i after everthing ran.
            {
                a += cmbt.GetPlayerInventory()[i]; // This function returns a list so you have to give it an index number

                if (i != cmbt.GetPlayerInventory().Count - 1) // an if statement runs when the given condition is true
                {
                    a += ", ";
                }
            }

            return a;
        }

        /// <summary>
        /// A random number generator with a minimum number and a maximum number as parameters and returns the random number.
        /// </summary>

        public int RandomNumGen(int min, int max)
        {
            Random rnd = new Random(); // makes a new random variable called rnd
            return rnd.Next(min, max); // returns rnd with function next, next makes it so the first argument is the minimum number and the second is a max.
        }

        /// <summary>
        /// Returns boolean inputCheck
        /// </summary>

        public bool GetInputCheck()
        {
            return inputCheck;
        }

        /// <summary>
        /// Sets boolean inputCheck to true
        /// </summary>

        public void InputCheckTrue()
        {
            inputCheck = true;
        }

        /// <summary>
        /// Sets boolean inputCheck to false
        /// </summary>

        public void InputCheckFalse()
        {
            inputCheck = false;
        }

        /// <summary>
        /// Credits
        /// </summary>

        public void Credits()
        {
            Print("This game was made possible by Trabzonspor and also a little bit by Abdurrahman Esat Yavuz.\nWe hope you had fun and look forward to seeing you again in the future.\n\nBIZE HER YER TRABZON!", 20);
            PressAnyKeyToContinue();
        }
    }
}