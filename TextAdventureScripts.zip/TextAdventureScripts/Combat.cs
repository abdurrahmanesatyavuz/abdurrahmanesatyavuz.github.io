﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace J1P2_PRO_Prototype2_Esat_Yavuz
{
    internal class Combat
    {
        Tools tls;
        List<string> playerInventory = new List<string>() { "Light stick", "Bandage" }; // A list is like a variable except you can add and remove values while the code is running

        int playerHP = 20;
        int enemyHP = 5;
        int endBossHP = 15;

        int playerDMG = 0;
        int enemyDMG = 0;

        int playerHeavyATT = 4;
        int endBossHeavyATT = 2;

        int rndChance;

        bool playerDefending = false;
        bool playerBleeding = false;

        public Combat(Tools pTls)
        {
            tls = pTls;
        }

        public void CombatCheck()
        {
            tls.Print("There is an enemy here what would you like to do, sneak or attack him?\n", 20);

            string playerDecision = tls.UserInput();
            do
            {
                if (playerDecision == "attack" || playerDecision == "attack him")
                {
                    PvE();
                    break;
                }

                else if (playerDecision == "sneak" || playerDecision == "sneak past" || playerDecision == "sneak past him")
                {
                    if (tls.RandomNumGen(0, 11) > 6)
                    {
                        tls.Print("You have succesfully sneaked past the zombie.\n", 20);
                        break;
                    }

                    else
                    {
                        tls.Print("The zombie has spotted you.", 20);
                        PvE();
                        break;
                    }
                }

                else
                {
                    tls.Print("Please input either attack or sneak.", 20);
                }
            }
            while (true);
        }

        void PvE()
        {
            while (enemyHP >= 0 || playerHP >= 0)
            {
                tls.Print("\nTo attack input attack, to defend input defend, to do a heavy attack input heavy attack.\n", 20);

                tls.Print($"Your HP is {playerHP}, the enemy's HP is {enemyHP}.\n", 20);

                string playerChoice = tls.UserInput();
                rndChance = tls.RandomNumGen(0, 9);

                if (playerChoice == "attack" || playerChoice == "punch" || playerChoice == "kick")
                {
                    tls.Print("\nYou are attacking your target\n", 20);

                    pDMG(1, 3);
                }

                else if (playerChoice == "heavy attack" || playerChoice == "heavy punch" || playerChoice == "heavy kick")
                {
                    playerHeavyATT--;

                    tls.Print($"\nYou have used one of your heavy attacks, you have {playerHeavyATT} remaining.\n", 20);

                    pDMG(3, 5);

                }

                else if (playerChoice == "defend" || playerChoice == "guard" || playerChoice == "protect")
                {
                    tls.Print("\nYou are now defending yourself.\n", 20);

                    playerDefending = true;
                }

                else
                {
                    tls.Print("\nYou have not input anything or didnt input the correct word.\n", 20);
                }

                int enemyBehaivor = tls.RandomNumGen(0, 3);

                if (enemyBehaivor != 1)
                {
                    tls.Print("\nThe enemy is attacking you.\n", 20);

                    eDMG(1, 3);
                }

                else
                {
                    tls.Print("\nThe enemy is attacking you with a bleed attack.\n", 20);

                    eDMG(2, 4);

                    playerBleeding = true;
                }


                if (playerDefending == true)
                {
                    enemyDMG = 1;
                }

                tls.Print($"\nThe player has done {playerDMG} damage, the enemy has done {enemyDMG} damage.\n", 20);

                enemyHP -= playerDMG;
                playerHP -= enemyDMG;

                playerDefending = false;

                playerDMG = 0;
                enemyDMG = 0;

                if (playerHP <= 0)
                {
                    tls.Print("\nYou are dead.\nThe game will end after you press any key, goodbye.\n", 20);
                    Console.ReadKey(true);
                    Environment.Exit(0);
                }

                if (enemyHP <= 0)
                {
                    tls.Print("\nYou have killed your enemy.\n", 20);
                    tls.PressAnyKeyToContinue();
                    break;
                }
            }

            enemyHP = 5;
        }

        public void EndBoss()
        {
            do
            {
                tls.Print("\nTo attack input attack, to defend input defend, to do a heavy attack input heavy attack.\n", 20);

                tls.Print($"Your HP is {playerHP}, the viscachas HP is {endBossHP}.\n", 20);

                string playerChoice = tls.UserInput();
                rndChance = tls.RandomNumGen(0, 9);

                if (playerChoice == "attack" || playerChoice == "punch" || playerChoice == "kick")
                {
                    tls.Print("\nYou are attacking the viscacha\n", 20);

                    pDMG(1, 3);
                }

                else if (playerChoice == "heavy attack" || playerChoice == "heavy punch" || playerChoice == "heavy kick")
                {
                    playerHeavyATT--;

                    tls.Print($"\nYou have used one of your heavy attacks, you have {playerHeavyATT} remaining.\n", 20);

                    pDMG(3, 5);

                }

                else if (playerChoice == "defend" || playerChoice == "guard" || playerChoice == "protect")
                {
                    tls.Print("\nYou are now defending yourself.\n", 20);

                    playerDefending = true;
                }

                else
                {
                    tls.Print("\nYou have not input anything or didnt input the correct word.\n", 20);
                }

                int enemyBehaivor = tls.RandomNumGen(0, 3);

                if (enemyBehaivor != 1)
                {
                    tls.Print("\nThe viscacha is attacking you.\n", 20);

                    eDMG(1, 3);
                }

                else
                {
                    tls.Print($"\nThe viscacha is using a heavy attack. It has {endBossHeavyATT} remaining.\n", 20);

                    eDMG(3, 5);
                }


                if (playerDefending == true)
                {
                    enemyDMG = 1;
                }

                tls.Print($"\nThe player has done {playerDMG} damage, the viscacha has done {enemyDMG} damage.\n", 20);

                endBossHP -= playerDMG;
                playerHP -= enemyDMG;

                playerDefending = false;

                playerDMG = 0;
                enemyDMG = 0;

                if (playerHP <= 0)
                {
                    tls.Print("\nYou are dead.\nThe game will end after you press any key, goodbye.\n", 20);
                    Console.ReadKey(true);
                    Environment.Exit(0);
                }

                if (endBossHP <= 0)
                {
                    tls.Print("\nYou have killed the viscacha!.\n", 20);
                    tls.PressAnyKeyToContinue();
                    tls.Credits();
                    Environment.Exit(0);
                    break;
                }
            }
            while (endBossHP >= 0 || playerHP >= 0);
        }

        void pDMG(int pMinNum, int pMaxNum)
        {
            if (rndChance != 5)
            {
                playerDMG = tls.RandomNumGen(pMinNum, pMaxNum);
            }

            else if (rndChance == 6)
            {
                playerDMG = tls.RandomNumGen(pMinNum, pMaxNum) * 2; //Critikal modifier
            }

            else
            {
                tls.Print("Player has missed their target.", 20);
            }
        }

        void eDMG(int pMinNum, int pMaxNum)
        {
            if (rndChance != 4)
            {
                enemyDMG = tls.RandomNumGen(pMinNum, pMaxNum);
            }

            else if (rndChance == 7)
            {
                enemyDMG = tls.RandomNumGen(pMinNum, pMaxNum) * 2; //Critikal modifier
            }

            else
            {
                tls.Print("Enemy has missed their target.", 20);
            }
        }

        public List<string> GetPlayerInventory()
        {
            return playerInventory;
        }

        public int GetPlayerHP()
        {
            return playerHP;
        }

        public bool GetPlayerBleeding()
        {
            return playerBleeding;
        }

        public void PlayerBleeding()
        {
            playerHP--;
            tls.Print("You are bleeding! Use a bandage to stop this.", 20);
        }

        public void PlayerStoppedBleeding()
        {
            playerBleeding = false;
        }

        public void PlayerHealing()
        {
            if (GetPlayerInventory().Contains("Apple"))
            {
                GetPlayerInventory().Remove("Apple");

                PlayerHealingCheck();
            }

            else if (GetPlayerInventory().Contains("Pear"))
            {
                GetPlayerInventory().Remove("Pear");

                PlayerHealingCheck();
            }

            else if (GetPlayerInventory().Contains("Plum"))
            {
                GetPlayerInventory().Remove("Plum");

                PlayerHealingCheck();
            }
        }

        void PlayerHealingCheck()
        {
            playerHP += 5;

            if (playerHP >= 20)
            {
                playerHP = 20;
            }
        }
    }
}