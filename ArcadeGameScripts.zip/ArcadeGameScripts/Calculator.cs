using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Calculator : MonoBehaviour
{
    public int indexOperator = 0;
    public int[,] allNumbers = { { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }, { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } }; // eerste array in de 2d array is voor plus, tweede is voor min en derde is voor keer sommen

    public int[] textVariables = { 0, 0, 0 }; // eerste variable is de eerste antwoord en de tweede de tweede antwoord, de derde is voor de som die word gemaakt

    public int whichClick = 0;

    private int score;

    public TextMeshProUGUI clickedAnswers; // In de inspector sleep ik de TMP hier in
    public TextMeshProUGUI correctOrFalse;

    //Score score; // Ik roep hier de score script/class maar deze script heeft nog geen toegang
    //GameObject CalculateObject = null; // Ik maak hier een score en gameobject aan en later geef ik het een waarde

    // Start is called before the first frame update
    void Start()
    {
        //CalculateObject = GameObject.Find("CalculateObject"); // Hij zoekt voor de gameobject genaamd CalculateObject
        //score = CalculateObject.GetComponent<Score>(); // En hier pakt hij de component Score op van CalculateObject

        NewSum(); // Ik roep hier een Method aan
    }

    // Update is called once per frame
    void Update()
    {
        OutputSum(); // Ik roep hier een method

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return)) // IF Input KeyDown is Return of Space (return is enter) dan voert hij de code uit in de scope van de if statement
        {
            if (indexOperator == 0) CalculatePlus(); // IF statement execute de code en de scope alleen als de gegeven condition true is
            else if (indexOperator == 1) CalculateMinus();
            else if (indexOperator == 2) CalculateMultiply();
        }

        PlayerPrefs.SetInt("Score", score);
    }

    /// <summary>
    /// Maakt een nieuwe som aan en reset de antwoord
    /// </summary>

    public void NewSum()
    {
        if (indexOperator == 0) textVariables[2] = allNumbers[indexOperator, Random.Range(0, 9)] + allNumbers[indexOperator, Random.Range(0, 9)]; // Random.Range is een random nummer generator in unity. De eerste is de min nummer en de laatste is de max nummer.
        else if (indexOperator == 1) textVariables[2] = allNumbers[indexOperator, Random.Range(0, 9)] - allNumbers[indexOperator, Random.Range(0, 4)];
        else if (indexOperator == 2) textVariables[2] = allNumbers[indexOperator, Random.Range(0, 9)] * allNumbers[indexOperator, Random.Range(0, 9)];

        textVariables[1] = 0; // De 
        textVariables[0] = 0;
        whichClick = 0; // Ik reset de whichClick hier omdat er een nieuwe som genereert
    }

    /// <summary>
    /// Output naar de scherm text voor wanneer de gebruiker een object aanklikt
    /// </summary>

    private void OutputSum()
    {
        if (indexOperator == 0) clickedAnswers.text = $"{textVariables[0]} + {textVariables[1]} = {textVariables[2]}";
        else if (indexOperator == 1) clickedAnswers.text = $"{textVariables[0]} - {textVariables[1]} = {textVariables[2]}";
        else if (indexOperator == 2) clickedAnswers.text = $"{textVariables[0]} X {textVariables[1]} = {textVariables[2]}";
    }

    /// <summary>
    /// Slaat op welke nummer de gebruiker heeft geklikt in textVariables[0] of [1]
    /// </summary>

    public void MouseClick(int index, int pressedNum) // Parameters zijn variables die je alleen binnen de methode kan gebruiken, wanneer de methode ergens word opgeroepen moet je argumenten doorgeven anders krijg je een error.
    {
        textVariables[index] = pressedNum;
    }

    /// <summary>
    /// Berekent of de gegeven plus antwoord goed of fout is
    /// </summary>

    private void CalculatePlus()
    {
        if (textVariables[0] + textVariables[1] == textVariables[2]) AnswerCorrect(); // IF textVariables[0] plus textVariables[1] is gelijk aan textVariables[2] 
        else if (textVariables[0] + textVariables[1] != textVariables[2]) AnswerWrong(); // ELSE IF voert alleen uit als de IF statement fout is, hij checked wel de statement van de else if voordat hij de code execute
    }

    /// <summary>
    /// Berekent of de gegeven min antwoord goed of fout is
    /// </summary>

    private void CalculateMinus()
    {
        if (textVariables[0] - textVariables[1] == textVariables[2]) AnswerCorrect();
        else if (textVariables[0] - textVariables[1] != textVariables[2]) AnswerWrong();
    }

    /// <summary>
    /// Berekent of de gegeven keer antwoord goed of fout is
    /// </summary>

    private void CalculateMultiply()
    {
        if (textVariables[0] * textVariables[1] == textVariables[2]) AnswerCorrect();
        else if (textVariables[0] * textVariables[1] != textVariables[2]) AnswerWrong();
    }

    /// <summary>
    /// Output een groene "correct!" op het scherm, maakt de game een nieuwe som en geeft hij de gebruiker +5 score.
    /// </summary>

    private void AnswerCorrect()
    {
        correctOrFalse.color = Color.green; // Hier maak ik de kleur van de text van correctOrFalse groen
        correctOrFalse.text = "correct!"; // Hier verander ik de text met een string
        NewSum();
        score += 5; // De score krijgt 5 meer omdat de antwoord correct is
    }

    /// <summary>
    /// Output een rode "false!" op het scherm en verandert de scene naar de GameOver scene.
    /// </summary>

    private void AnswerWrong()
    {
        correctOrFalse.color = Color.red;
        correctOrFalse.text = "false!";
        SceneManager.LoadScene("GameOver"); // Loads another scene, you can either use the name of the scene or the index of the scene
    }
}