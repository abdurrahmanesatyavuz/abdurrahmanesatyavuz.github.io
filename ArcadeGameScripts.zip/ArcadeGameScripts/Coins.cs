using TMPro;
using UnityEngine;

public class Coins : MonoBehaviour
{
    public int coins = 3;
    public TextMeshProUGUI coinsUI;

    public static Coins instance = null;

    void Awake() // De awake destroyed een duplicate gameobject als er eentje word gemaakt
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }


    // Update is called once per frame
    void Update()
    {
        DontDestroyOnLoad(gameObject); // Hier verwijderd hij de gameobject niet als hij van scene veranderd
    }
}
