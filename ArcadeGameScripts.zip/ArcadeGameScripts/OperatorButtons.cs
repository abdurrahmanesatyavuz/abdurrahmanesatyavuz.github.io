using UnityEngine;
using UnityEngine.SceneManagement;

public class OperatorButtons : MonoBehaviour
{
    Coins coins;
    GameObject CoinsObject = null;

    private void Awake()
    {
        CoinsObject = GameObject.Find("CoinsObject");
        coins = CoinsObject.GetComponent<Coins>();
    }

    public void Quit()
    {
        Application.Quit();
    }

    public void LoadScene(string p)
    {
        SceneManager.LoadScene(p);
    }

    public void CheckCoins()
    {
        if (coins.coins <= 0) 
        {
            coins.coinsUI.color = Color.red;
            coins.coinsUI.text = "Not enough coins!";
        }
        else if (coins.coins > 0)
        {
            coins.coins--;
            LoadScene("OptionsOperators");
        }
    }
}
