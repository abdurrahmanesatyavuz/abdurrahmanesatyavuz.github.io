using UnityEngine;

public class SpritePress : MonoBehaviour
{
    Calculator calc; 
    GameObject CalculateObject = null;

    public int indexAllNumbers; // in de unity inspector zet ik hier in welke index de nummer heeft

    // Start is called before the first frame update
    void Start()
    {
        CalculateObject = GameObject.Find("CalculateObject");
        calc = CalculateObject.GetComponent<Calculator>();
    }

    private void OnMouseDown()
    {
        calc.MouseClick(calc.whichClick % 2, calc.allNumbers[calc.indexOperator, indexAllNumbers]); //calc.whichClick % 2 returned altijd of 0 of 1, omdat er altijd een 2 past in een even getal.
        calc.whichClick++; // Increment: voegt +1 naar de gegeven int variable
    }
}