using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Xml.Serialization;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CoinEarner : MonoBehaviour
{
    Coins coins;
    GameObject CoinsObject = null;

    [SerializeField] private TextMeshProUGUI tijdUI;
    [SerializeField] private TextMeshProUGUI somUI;
    [SerializeField] private TMP_InputField inputUI;

    private int time = 30;
    private float timer;
    private float lap = 1f;

    private int num1;
    private int num2;
    private int sum;

    private int sumCheck;

    private void Awake()
    {
        CoinsObject = GameObject.Find("CoinsObject");
        coins = CoinsObject.GetComponent<Coins>();
    }

    // Start is called before the first frame update
    void Start()
    {
        num1 = Random.Range(0, 101);
        num2 = Random.Range(0, 101);
        sum = num1 + num2;
        somUI.text = $"{num1} + {num2}";
        print(sum);
    }

    // Update is called once per frame
    void Update()
    {
        Countdown();

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
        {
            sumCheck = int.Parse(inputUI.text);

            if (sum == sumCheck)
            {
                coins.coins++;
                SceneManager.LoadScene("MainMenu");
            }
            else
            {
                SceneManager.LoadScene("MainMenu");
            }
        }
    }

    private void Countdown()
    {
        timer += Time.deltaTime;

        if (0 >= time)
        {
            SceneManager.LoadScene("MainMenu");
        }
        else if (timer > lap)
        {
            tijdUI.text = $"{time}";
            time -= 1;
            timer = 0f;
        }
    }
}