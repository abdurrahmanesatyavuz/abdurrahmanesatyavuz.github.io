using UnityEngine;
using TMPro;

public class Score : MonoBehaviour
{
    public TextMeshProUGUI scoreHighscoreUI;

    void Start()
    {
        scoreHighscoreUI.text = $"score: {PlayerPrefs.GetInt("Score")} highscore: {PlayerPrefs.GetInt("HighScore")}"; // PlayerPrefs.Getint pakt de int HighScore op die in PlayerPrefs is opgeslagen
    }

    void Update()
    {
        scoreHighscoreUI.text = $"score: {PlayerPrefs.GetInt("Score")} highscore: {PlayerPrefs.GetInt("HighScore")}"; // Interpollation maakt variables zetten in een string veel makkelijker, in plaats van heletijd "" + variable + "" te gebruiken. Gebruik je $"{variable}"
        if (PlayerPrefs.GetInt("Score") > PlayerPrefs.GetInt("HighScore"))
        {
            PlayerPrefs.SetInt("HighScore", PlayerPrefs.GetInt("Score")); // Hier slaat PlayerPrefs de variable score op als HighScore
        }
    }
}