using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class CoinsOutput : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI coinsText;

    Coins coins;
    GameObject CoinsObject = null;

    // Start is called before the first frame update
    void Start()
    {
        CoinsObject = GameObject.Find("CoinsObject");
        coins = CoinsObject.GetComponent<Coins>();
    }

    // Update is called once per frame
    void Update()
    {
        coinsText.text = $"Coins: {coins.coins}";
    }
}
